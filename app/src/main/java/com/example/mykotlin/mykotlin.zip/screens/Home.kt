package com.example.mykotlin.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavHost
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.mykotlin.R
import com.example.mykotlin.model.Cart
import com.example.mykotlin.model.UserInfo

data class TabBarItem(
    val title: String,
    val selectedIcon: Int,
    val unselectedIcon: Int,
)

class Home {
    @Composable
    fun Container (
        saveUserInfo: (UserInfo) -> Unit,
        goToSreen: (String) -> Unit,
        cartInfo: List<Cart>,
        updateCart: (Cart) -> Unit
        ){
        Column {
//            Text(text = "home")
//            Button(onClick = {
//                //call api logout
//                // logout thanh cong
//                saveUserInfo(UserInfo(null, null, null, null))
//            }) {
//                Text(text = "Logout")
//            }
//
//            // chuyen man hinh chi tiet
//
//            Button(onClick = {
//                val value = 123
//                goToSreen("detail/$value")
//            }) {
//                Text(text = "detail chi tiết")
//            }
            MainTabs(
                saveUserInfo = { saveUserInfo(it) },
                goToSreen = goToSreen,
                cartInfo = cartInfo,
                updateCart = { updateCart(it)}
            )

        }

    }

    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    @Composable
    fun MainTabs(
        saveUserInfo: (UserInfo) -> Unit,
        goToSreen: (String) -> Unit,
        cartInfo: List<Cart>,
        updateCart: (Cart) -> Unit
    ) {
        // setting up the individual tabs
        val homeTab = TabBarItem(
            title = "Home",
            selectedIcon = R.drawable.nha,
            unselectedIcon = R.drawable.nha2
        )
        val alertsTab = TabBarItem(
            title = "Alerts",
            selectedIcon = R.drawable.chuong,
            unselectedIcon = R.drawable.chuong2
        )
        val settingsTab = TabBarItem(
            title = "Settings",
            selectedIcon = R.drawable.xem,
            unselectedIcon = R.drawable.xem2
        )
        val moreTab = TabBarItem(
            title = "More",
            selectedIcon = R.drawable.canhan,
            unselectedIcon = R.drawable.canhan2
        )

        // creating a list of all the tabs
        val tabBarItems = listOf(homeTab, alertsTab, settingsTab, moreTab)
        // creating our navController
        val navController = rememberNavController()

        //khoi tao cac man hinh
        var alertScreen = Alerts()
        var homeScreen = HomeTab()

        //tinh tong tien gio hang
        var sum = 0f
        for (item in cartInfo){
            if (item.product.price != null){
                sum += item.product.price * item.quantity
            }
        }

        Scaffold(bottomBar = { TabView(tabBarItems, navController) }) {
            NavHost(navController = navController, startDestination = homeTab.title) {
                composable(homeTab.title) {
                    homeScreen.Container(goToSreen = {goToSreen(it)})
                }
                composable(alertsTab.title) {
                    alertScreen.Container()
                }
                composable(settingsTab.title) {
//                    Text(settingsTab.title)
                    //hien thi gio hang
                    Column {
                        LazyColumn {
                            items(cartInfo){ item ->
                                Column {
                                    Text(text = "Product: ${item.product.name}")
                                    Text(text = "quantity: ${item.quantity}")

                                    Button(onClick = {
                                        updateCart(Cart(item.product, 1))
                                    }) {
                                        Text(text = "tang")
                                    }

                                    Button(onClick = {
                                        updateCart(Cart(item.product, -1))
                                    }) {
                                        Text(text = "giam")
                                    }

                                    Spacer(modifier = Modifier.height(20.dp))

                                }
                            }
                        }
                        Text(text = "Tong tien: $sum")
                    }
                }
                composable(moreTab.title) {
                    Button(onClick = {
                        saveUserInfo(UserInfo(null, null, null, null))
                    }) {
                        Text(text = "logout")
                    }
                }
            }
        }
    }

    @Composable
    fun TabView(tabBarItems: List<TabBarItem>, navController: NavController) {
        var selectedTabIndex by rememberSaveable {
            mutableIntStateOf(0)
        }
        NavigationBar {
            tabBarItems.forEachIndexed { index, tabBarItem ->
                NavigationBarItem(
                    selected = selectedTabIndex == index,
                    onClick = {
                        selectedTabIndex = index
                        navController.navigate(tabBarItem.title)
                    },
                    icon = {
                        TabBarIconView(
                            isSelected = selectedTabIndex == index,
                            selectedIcon = tabBarItem.selectedIcon,
                            unselectedIcon = tabBarItem.unselectedIcon,
                            title = tabBarItem.title,
                        )
                    },
                    label = { Text(tabBarItem.title) })
            }
        }
    }

    @Composable
    fun TabBarIconView(
        isSelected: Boolean,
        selectedIcon: Int,
        unselectedIcon: Int,
        title: String,
    ) {
        Image(
            painter = painterResource(id = if (isSelected) selectedIcon else unselectedIcon),
            modifier = Modifier
                .width(24.dp)
                .height(24.dp),
            contentDescription = title
        )
    }
}