package com.example.mykotlin.screens


import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import coil.size.Size
import com.example.mykotlin.helpers.RetrofitAPI
import com.example.mykotlin.httpmodels.ProductModel
import com.example.mykotlin.httpmodels.ProductResponeModel


class HomeTab {

    @Composable
    fun Container( goToSreen: (String) -> Unit) {
        var listProducts by remember{
            mutableStateOf(listOf<ProductModel>())
        }

        fun getProductsCallback(response: ProductResponeModel?){
            val products = response?.products
            listProducts = products ?: listOf()
        }

        fun getProductsByCategoryId(){
            val category: String = "65b07ddcfc13ae4836b4cb08"
            val api = RetrofitAPI()
            try {
                api.getProductsCategoryID(category, ::getProductsCallback)
            } catch (e: Exception) {
                Log.d(">>>>TAG", "getProductsByCategoryId: ${e.message}")
            }
        }

        getProductsByCategoryId()

        // 1. sử dụng lazy row
        // 2. sử dụng flow row

        LazyColumn {
            items(listProducts) { product ->
                val painter = rememberAsyncImagePainter(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(product.image)
                        .size(Size.ORIGINAL)
                        .build()
                )
                Column {
                    Text(text = product.name ?: "")
                    Image(painter = painter, contentDescription = "")
                    Button(onClick = { goToSreen("detail/${product._id}") }) {
                        Text(text = "Chi tiet")
                    }
                }
            }
        }
    }
}