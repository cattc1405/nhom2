package com.example.mykotlin.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import coil.compose.AsyncImage
import com.example.mykotlin.helpers.RetrofitAPI
import com.example.mykotlin.httpmodels.ProductDetailReponseModel
import com.example.mykotlin.httpmodels.ProductModel
import com.example.mykotlin.model.Cart


class Detail {

    @Composable
    fun Container(value: String?, updateCart: (Cart) -> Unit) {
        // Detail screen
        // read from arguments and show the detail screen
        var product by remember {
            mutableStateOf(
                ProductModel(
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
                )
            )
        }

        fun getProductCallback(result: ProductDetailReponseModel?) {
            if (result != null) {
                product = result.product
            }
        }

        fun getProductById() {
            try {
                val api = RetrofitAPI()
                api.getProductByID(value, ::getProductCallback)
            } catch (e: Exception) {

            }
        }
        getProductById()
        // hien thi chi tiet san pham
        Column {
            AsyncImage(model = product.image, contentDescription = "")
            Text(text = "Detail Screen: ${product.name}")
            Text(text = "Description: ${product.description}")
            Text(text = "Price: ${product.price}")
            Button(onClick = {
                var item = Cart(product, 1)
                updateCart(item)
            }) {
                Text(text = "Them vao gio hang")
            }
        }
    }
}