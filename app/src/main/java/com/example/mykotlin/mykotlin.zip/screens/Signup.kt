package com.example.mykotlin.screens

import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mykotlin.R
import com.example.mykotlin.asm.Login2Activity
import com.example.mykotlin.helpers.RetrofitAPI
import com.example.mykotlin.httpmodels.RegisterRequestModel
import com.example.mykotlin.httpmodels.RegisterResponseModel
import com.example.mykotlin.ui.theme.TextColor2
import com.example.mykotlin.ui.theme.TextColor3
import com.example.mykotlin.ui.theme.TextColor4

class Signup {
    @Composable
    fun Container (goToSreen: (String) -> Unit){
        Body(goToSreen = goToSreen)
    }

    @Composable
    fun Body(goToSreen: (String) -> Unit) {
        val context = LocalContext.current
        var email by remember { mutableStateOf("nam123@gmail.com") }
        var password by remember { mutableStateOf("1") }
        var name by remember { mutableStateOf("nguyen nam") }


        fun registerCallback(response: RegisterResponseModel?) {
            // hien thong bao thanh cong
            Toast.makeText(context, "Register success", Toast.LENGTH_SHORT).show()
            // quay ve login
            goToSreen("login")
        }

        fun onClickRegister() {
            try {
                val retrofitAPI = RetrofitAPI()
                val body = RegisterRequestModel(
                    name = name, email = email,
                    password = password
                )
                retrofitAPI.register(body = body, callback = { registerCallback(it) })
            } catch (e: Exception) {
                Log.d(">>>>>>", "Failed to register: ${e.message}")
            }
        }
        Column {
            Image(
                painter = painterResource(id = R.drawable.anh1),
                contentDescription = "Sample Image",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .padding(30.dp)
                    .width(80.dp)
                    .height(80.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .align(Alignment.CenterHorizontally)
            )


        Column {

            Text(
                text = "Welcome".uppercase(),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = TextColor2,
                modifier = Modifier
                    .padding(start = 18.dp, bottom = 30.dp)
            )
            Box(
                modifier = Modifier
                    .shadow(8.dp, shape = MaterialTheme.shapes.medium)

            ) {
                Column {
                    TextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text(text = "Email") },

                        modifier = Modifier
                            .padding(vertical = 17.dp, horizontal = 12.dp)
                            .fillMaxWidth()
//                            .background(TextColor4),

                    )

                    TextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text(text = "Password") },

                        modifier = Modifier
                            .padding(vertical = 12.dp, horizontal = 12.dp)
                            .fillMaxWidth(),
//                        colors = TextFieldDefaults.textFieldColors(
//                            backgroundColor = TextColor4
//                        )

                    )

                    TextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(text = "Name") },
                        modifier = Modifier
                            .padding(vertical = 12.dp, horizontal = 12.dp)
                            .fillMaxWidth(),
//                colors = TextFieldDefaults.textFieldColors(
//                    textColor = TextColor1,
//                    backgroundColor = TextColor4
//                )
                    )

//                    TextField(
//                        value = textState4.value,
//                        onValueChange = { textState4.value = it },
//                        label = { Text("Confirm Password") },
//                        modifier = Modifier
//                            .padding(vertical = 12.dp, horizontal = 12.dp)
//                            .fillMaxWidth(),
////                colors = TextFieldDefaults.textFieldColors(
////                    textColor = TextColor1,
////                    backgroundColor = TextColor4
////                )
//                    )

                    TextButton(
                        modifier = Modifier
                            .padding(vertical = 20.dp, horizontal = 20.dp,)
                            .align(Alignment.CenterHorizontally)
                            .fillMaxWidth()
                            .height(55.dp)
                            .background(
                                TextColor3,
                                shape = MaterialTheme.shapes.small
                            ),
                        onClick = {
                            onClickRegister()
                        }
                    ) {
                        Text(
                            text = "Sign up".uppercase(),
                            color = TextColor4,
                            fontSize = 18.sp
                        )
                    }

                    Row(

                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)

                    ) {
                        Text(
                            text = "Already have accout?",
//                            fontFamily = nunitorsansNormalFont,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextColor2,
                            modifier = Modifier
                                .padding(vertical = 11.dp)

                        )
                        TextButton(
                            modifier = Modifier
                                .padding(vertical = 1.dp, horizontal = 1.dp)
//                        .align(Alignment.CenterHorizontally)

                            ,
                            onClick = {
                                goToSreen("login")
                            }
                        ) {
                            Text(
                                text = "login".uppercase(),
                                color = TextColor3,
                                fontSize = 18.sp
                            )
                        }

                    }
                }
            }
        }

        }
    }

}